package com.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.pojo.Department;
import com.app.service.DepartmentService;

@Controller
@RequestMapping("/department")
public class DepartmentController {
	// dependancy
	@Autowired
	private DepartmentService deprtmentSer;

	// show departments
	@GetMapping("/departments")
	public String displayDepartment(Model map) {
		System.out.println("in display controller");
		List<Department> dept = new ArrayList<>();
		try {
			System.out.println("in fetch try");
			dept = deprtmentSer.fetchAllDept();
			System.out.println("dep "+dept);
			map.addAttribute("deptments", dept);
			if(dept==null) {
				map.addAttribute("message", "Something wrong - data not fetch");
			}else {
				map.addAttribute("message", "Department Fetch Successfully");
			}
		}catch (RuntimeException e) {
			System.out.println("in fetch catch");
			System.out.println("in display dept catch error - "+e);
			map.addAttribute("message", "Something wrong - data not fetch");
		}
		return "/department/departments";
	}
}
