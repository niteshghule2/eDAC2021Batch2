package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojo.Employee;
import com.app.service.EmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	// dependany
	@Autowired
	private EmployeeService employeeService;

	@GetMapping("hire")
	public String showHireEmployee(Employee employee, @RequestParam int depid, HttpSession session) {
		session.setAttribute("depid", depid);
		return "/employee/hire";
	}

	@PostMapping("/hire")
	public String processEmployeeDetails(Employee employee, HttpSession session, RedirectAttributes flashMap,
			Model map) {
		int depid = (Integer) session.getAttribute("depid");
		System.out.println("depid = "+depid+" & employee = "+employee);
		try {
			flashMap.addFlashAttribute("flash_message", employeeService.hireEmployee(depid, employee));
			session.invalidate();
			return "redirect:/department/departments";
		} catch (RuntimeException e) {
			map.addAttribute("message", e.getMessage());
			return "/employee/hire";
		}
	}
}
