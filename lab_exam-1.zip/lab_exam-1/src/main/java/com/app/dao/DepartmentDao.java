package com.app.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.Department;
@Repository
public class DepartmentDao implements IDepartmentDao {
	// dependancy
	@Autowired
	private EntityManager manager;

	@Override
	public List<Department> fetchAllDepartment() {
		System.out.println("in fetchAll dao");
		List<Department> list = new ArrayList<>();
		String jpql = "select d from Department d";
		list = manager.createQuery(jpql, Department.class).getResultList();
		return list;
	}

}
