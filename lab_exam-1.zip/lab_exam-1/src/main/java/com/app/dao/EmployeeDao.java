package com.app.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.Department;
import com.app.pojo.Employee;

import custom_excep.CustomerException;

@Repository

public class EmployeeDao implements IEmployeeDao {
	// dependancy
	@Autowired
	private EntityManager manager;

	@Override
	public String hireEmployee(int depid, Employee employee) {
		Department department = manager.find(Department.class, depid);
		department.addEmployee(employee);
		department.setStregth(department.getStregth()+1);
		try {
			manager.persist(department);
		} catch (RuntimeException e) {
			throw new CustomerException("Someting Wrong - check email id unquie");
		}
		return "Employee hire in depId = " + depid + " & Employee Id = " + employee.getId();
	}

}
