package com.app.dao;

import java.util.List;

import com.app.pojo.Department;

public interface IDepartmentDao {
	//fetch all department details
	List<Department> fetchAllDepartment();
}
