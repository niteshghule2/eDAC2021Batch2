package com.app.dao;

import com.app.pojo.Employee;

public interface IEmployeeDao {
	//hire employee to dept
	String hireEmployee(int depid, Employee employee);
}
