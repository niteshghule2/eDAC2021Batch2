package com.app.pojo;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "department_lab")
public class Department extends BaseEntity {
	@Column(name = "dept_name", length = 20)
	private String name;

	@Column(length = 20)
	private String location;
	private int stregth;
	@OneToMany(mappedBy = "department", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Employee> employee;

	public Department() {
		System.out.println("dept pojo");
	}
	public Department(String name, String location, Integer stregth) {
		super();
		this.name = name;
		this.location = location;
		this.stregth = stregth;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getStregth() {
		return stregth;
	}

	public void setStregth(int stregth) {
		this.stregth = stregth;
	}

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

	public void addEmployee(Employee employees) {

		employee.add(employees);// parent -> child
		employees.setDepartment(this);// child -> parent
	}

	public void removeEmployee(Employee employees) {

		employee.remove(employees);// parent -X -> child
		employees.setDepartment(null);// child -X-> parent
	}
	@Override
	public String toString() {
		return "Department [name=" + name + ", location=" + location + ", stregth=" + stregth + "]";
	}
	
	
}
