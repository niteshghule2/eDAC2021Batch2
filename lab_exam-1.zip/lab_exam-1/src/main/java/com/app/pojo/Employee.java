package com.app.pojo;

import java.time.LocalDate;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "employee_lab")
public class Employee extends BaseEntity {
	@Column(length = 50)
	private String name;
	@Column(length = 50, unique = true)
	private String email;
	@Transient
	private double salary;
	@Transient
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dob;
	
	@Column(name = "hire_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate hireDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "dept_id")
	private Department department;
	
	public Employee() {
		System.out.println("employee pojo");
	}

	public Employee(String name, String email, double salary, LocalDate dob, LocalDate hireDate) {
		super();
		this.name = name;
		this.email = email;
		this.salary = salary;
		this.dob = dob;
		this.hireDate = LocalDate.now();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", email=" + email + ", salary=" + salary + ", dob=" + dob + ", hireDate="
				+ hireDate + "]";
	}
	
	
	
	
	
	
}
