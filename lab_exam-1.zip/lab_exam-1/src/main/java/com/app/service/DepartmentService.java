package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.DepartmentDao;
import com.app.pojo.Department;
@Service
public class DepartmentService implements IDepartmentService {
	//dependancy
	@Autowired
	private DepartmentDao deprtmentDao;
	@Override
	public List<Department> fetchAllDept() {
		List<Department> list = new ArrayList<>();
		list = deprtmentDao.fetchAllDepartment();
		return list;
	}

}
