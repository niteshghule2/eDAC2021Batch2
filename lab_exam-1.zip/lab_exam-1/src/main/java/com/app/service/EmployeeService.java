package com.app.service;

import java.time.LocalDate;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.EmployeeDao;
import com.app.pojo.Employee;

import custom_excep.CustomerException;
@Service
@Transactional
public class EmployeeService implements IEmployeeService {
	//dependancy
	@Autowired
	private EmployeeDao employeeDao;
	@Override
	public String hireEmployee(int depid, Employee employee) {
		System.out.println("in employee service");
		String mesg;
		System.out.println("employee salary "+ employee.getSalary());
		if((employee.getSalary() > 30000) && (employee.getSalary() < 40000)) {
			int age = LocalDate.now().getYear()-employee.getDob().getYear();
			System.out.println("employe age = "+age);
			if(age>25&&age<35) {
				mesg= employeeDao.hireEmployee(depid, employee);
			}else {
				throw new CustomerException("Age not between 25 to 35");
			}
		}else {
			throw new CustomerException("Salary not in between 30k to 40K");
		}
		return mesg;
	}

}
