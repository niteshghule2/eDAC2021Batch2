package com.app.service;

import java.util.List;

import com.app.pojo.Department;

public interface IDepartmentService {
	//fetch all department details
	List<Department> fetchAllDept();
}
