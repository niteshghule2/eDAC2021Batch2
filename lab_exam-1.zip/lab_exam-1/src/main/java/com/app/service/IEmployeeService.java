package com.app.service;

import com.app.pojo.Employee;

public interface IEmployeeService {
	//hire employee
	String hireEmployee(int depid, Employee employee);
}
