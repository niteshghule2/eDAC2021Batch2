package custom_excep;



@SuppressWarnings("serial")
public class CustomerException extends RuntimeException{
	public CustomerException(String mesg) {
		super(mesg);
	}
}
